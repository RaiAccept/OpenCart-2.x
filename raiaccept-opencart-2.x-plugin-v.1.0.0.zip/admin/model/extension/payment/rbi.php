<?php
/**
 * Copyright (c) 2023 Raiffeisenbank International
*/

class ModelExtensionPaymentRbi extends Model {
	public function install() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "rbi_order` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `order_id` int(11) NOT NULL,
		  `mode` varchar(63) NOT NULL DEFAULT '',
		  `request` TEXT NOT NULL DEFAULT '',
		  `response` TEXT NOT NULL DEFAULT '',
		  `orderIdentification` varchar(255) NOT NULL DEFAULT '',
		  `phpsessid` varchar(255) NOT NULL DEFAULT '',
		  `currency` varchar(255),
		  `currency_value` varchar(255),
		  `refunded_amount` varchar(255) DEFAULT 0,
		  `refund_response` TEXT NOT NULL DEFAULT '',
		  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		  PRIMARY KEY (`id`),
		  KEY `order_id` (`order_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8;");

		$this->db->query("ALTER TABLE `" . DB_PREFIX . "rbi_order` ADD UNIQUE( `order_id`);");
	}

	public function addColumn($columnName, $tableName, $specifications, $after = false) {
		if (!$this->hasColumn($columnName, $tableName)) {
			$sql = "ALTER TABLE `" . DB_PREFIX . $tableName . "` ADD `$columnName` $specifications ";
			if ($after) {
				$sql .= " AFTER `$after`";
			}
			$this->db->query($sql);
		}
	}

	public function hasColumn($columnName, $tableName) {
		$query = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . $tableName . "` WHERE FIELD = '$columnName'");
		return boolval($query->num_rows);
	}

	public function deleteTables() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "rbi_order`");
	}

	public function editRbiOrder($order_id, $data) {
		$sql = "UPDATE `" . DB_PREFIX . "rbi_order` SET ";
		$sql_data = [];

		if (isset($data['refund_response'])) {
			$data['refund_response'] = is_array($data['refund_response']) ? serialize($data['refund_response']) : $data['refund_response'];
			$sql_data[] = " `refund_response` = '" . $this->db->escape($data['refund_response']) . "'";
		}

		if (isset($data['refunded_amount'])) {
			$sql_data[] = " `refunded_amount` = '" . $this->db->escape($data['refunded_amount']) . "'";
		}

		if ($sql_data) {
			$sql .= implode(',', $sql_data);
			$sql .= " WHERE `order_id` = " . (int)$order_id;

			$this->db->query($sql);
		}
	}

	public function getRbiOrder($order_id) {
		$result = $this->db->query("SELECT * FROM `" . DB_PREFIX . "rbi_order` WHERE order_id = " . (int)$order_id . " LIMIT 1");

		if (!$result->num_rows) {
			return [];
		}

		$result->row['request'] = unserialize($result->row['request']);
		$result->row['response'] = unserialize($result->row['response']);
		$result->row['refund_response'] = unserialize($result->row['refund_response']);

		return $result->row;
	}
}