<?php
/**
 * Copyright (c) 2023 Raiffeisenbank International
*/

// Heading
$_['heading_title']                        = 'Safe payments powered by Raiffeisen Bank';

// Text
$_['text_payment']                         = 'Payment';
$_['text_success']                         = 'Success: You have modified the RBI details!';
$_['text_rbi']                             = '<a onclick="window.open(\'https://rbinternational.com/\');"><img src="view/image/payment/rbi.png" alt="RBI" title="RBI" style="width: 140px;" /></a>';
$_['text_edit']                            = 'Edit Safe payments powered by Raiffeisen Bank';
$_['text_sandbox']                         = 'Sandbox';
$_['text_production']                      = 'Production';
$_['text_out_of']                          = ' out of ';
$_['text_iframe']                          = 'Iframe';
$_['text_redirect']                        = 'Redirect';
$_['text_none']                            = '-- none --';
$_['text_reiaccept_url']                   = 'https://www.raiaccept.com';
$_['text_reiaccept_email']                 = 'support@raiaccept.com';
$_['text_plugin_version']                  = 'OpenCart v.%s, Module v.%s';

// Tabs
$_['tab_general']                          = 'General';
$_['tab_advanced_settings']                = 'Advanced settings';

// Groups
$_['group_api_settings']                   = 'API settings';
$_['group_general_settings']               = 'General settings';
$_['group_contact_details']                = 'Contact Details RaiAccept';
$_['group_order_statuses']                 = 'Order Statuses';
$_['group_others']                         = 'Others';

// Button
$_['button_refund']                        = 'Return';
$_['button_refund_full']                   = 'Return the full amount';
$_['button_status']                        = 'Check';

// Entry
$_['entry_select_mode']                    = 'Select Mode:';
$_['entry_sandbox_username']               = 'Sandbox Username:';
$_['entry_sandbox_password']               = 'Sandbox Password:';
$_['entry_production_username']            = 'Production Username:';
$_['entry_production_password']            = 'Production Password:';
$_['entry_payment_form']                   = 'Payment form integration:';
$_['entry_description']                    = 'Order description:';
$_['entry_order_status_completed']         = 'Order Status Completed:';
$_['entry_order_status_refunded']          = 'Order Status Refunded:';
$_['entry_order_status_canceled']          = 'Order Status Canceled:';
$_['entry_order_status_failed']            = 'Order Status Failed:';
$_['entry_currency']                       = 'Payment Currency:';
$_['entry_geo_zone']                       = 'Geo Zone:';
$_['entry_status']                         = 'Plugin Status:';
$_['entry_refunded_amount']                = 'Refunded amount';
$_['entry_mode']                           = 'Mode';
$_['entry_refund']                         = 'Amount';
$_['entry_tran_statuses']                  = 'All Transactions Statuses';
$_['entry_debug']                          = 'Debug mode:';
$_['entry_sort_order']                     = 'Sort Order:';
$_['entry_total']                          = 'Minimum Eligible Amount';
$_['entry_website']                        = 'Website:';
$_['entry_email']                          = 'Email:';
$_['entry_version']                        = 'Plugin Version:';

// Help
$_['help_total']                           = 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']                     = 'Warning: You do not have permission to modify RBI!';
$_['error_credentials_production']         = 'Invalid Username or Password!';
$_['error_credentials_sandbox']            = 'Invalid Username or Password!';
$_['error_username']                       = 'Username Required!';
$_['error_password']                       = 'Password Required!';
$_['error_description_length']             = 'Your description must not be more than 200 symbols!';
$_['error_more_than_0']                    = 'The amount must be more than 0!';
$_['error_action_failed']                  = 'Failed attempt: (%s)';
$_['error_amount_exceeded']                = 'You can not enter a number that is more than the order total';
$_['error_invalid_number']                 = 'Enter a valid number';
$_['error_order_missing']                  = 'RBI order is missing or it is already refunded';
$_['error_general']                        = 'Please check carefully for errors!';
$_['error_request']                        = 'An error occurred on request:';

$_['text_transaction_id']                  = 'Transaction with ID';
$_['text_transaction_type']                = 'Type of';
$_['text_transaction_date']                = 'Made on';
$_['text_transaction_amount']              = 'At the Amount of';
$_['text_transaction_status']              = 'Has Status';

$_['text_trans_code']['0000'] = 'Transaction successful.';
$_['text_trans_code']['1001'] = 'Decline by Issuer: The card issuer suspects the transaction to be fraudulent and therefore refuses.';
$_['text_trans_code']['1002'] = 'Decline by Issuer: The card issuer indicates an issue with the card and requests contact from the consumer.';
$_['text_trans_code']['1003'] = 'The card issuer indicates an issue with the card and requests contact from the consumer. The consumer can use another payment method. Alternatively, the consumer can try again after they resolve the issue with their bank.';
$_['text_trans_code']['1004'] = 'Decline by Issuer: The transaction is not permitted. Either a restriction is applied by the Issuer to the cardholder, or the transaction is not permitted by law.';
$_['text_trans_code']['1005'] = 'Decline by Issuer: The card is reported as lost and therefore cannot be accepted. Consumer is advised to try again using a different payment method.';
$_['text_trans_code']['1006'] = 'Decline by Issuer: The card is reported as stolen and therefore cannot be accepted. Consumer is advised to try again using a different payment method.';
$_['text_trans_code']['1007'] = 'The transaction is identified as a duplicate and therefore is not processed. Verify uniqueness of the transaction elements (like Merchant Order Reference) or contact support.';
$_['text_trans_code']['1008'] = 'The original referencing transaction is missing or is invalid. Please reattempt only after you provide a correct referencing transaction or contact support.';
$_['text_trans_code']['1009'] = 'The selected currency is not supported for the Merchant and therefore the transaction cannot be processed.';
$_['text_trans_code']['2001'] = 'Restricted Card: The card issuer restricts where the card can be used. For example, because of embargoes.';
$_['text_trans_code']['2002'] = 'Invalid Merchant ID: Wrong merchant account is sent, merchant values are wrong when running the 3D-Secure flow, the web service used isn\'t permitted for that merchantAccountId, or the company is not active.';
$_['text_trans_code']['2003'] = 'The transaction amount is specified in an invalid format. For example, an invalid character such as a dollar sign or a space is used. Consumer should correct or use another payment method.';
$_['text_trans_code']['2004'] = 'Insufficient funds in the consumer\'s account. Consumer can try again after they add funds to their bank account or use another payment method.';
$_['text_trans_code']['2005'] = 'The credited amount exceeds the amount of the referenced debit transaction.';
$_['text_trans_code']['3001'] = 'Strong Customer Authentication is required for the transaction. If the transaction is in scope of PSD2 and did not go through 3-D Secure, retry with 3-D Secure. This is also referred to as a "Soft Decline".';
$_['text_trans_code']['3002'] = 'Decline by Issuer: The consumer is using an expired card.';
$_['text_trans_code']['3003'] = 'The card issuer is unable to validate the card/account number, possibly because an invalid character was used, or the card is not supported by the processor.';
$_['text_trans_code']['3004'] = 'The consumer either provides an expired card or the expiration date is invalid. Consumer is advised to use a valid expiry date or to try a different payment method.';
$_['text_trans_code']['3005'] = 'The consumer provides an incorrect CVV. Consumer is advised to use the correct CVV or to try different payment method.';
$_['text_trans_code']['3006'] = 'RaiAccept is unable to process the transaction due to a technical error with its processor.';
$_['text_trans_code']['3007'] = 'RaiAccept is unable to process the transaction due to a technical error with Payment Schemes.';
$_['text_trans_code']['4001'] = 'Generic refusal from the card issuer that has several possible causes.';
$_['text_trans_code']['5001'] = 'There are too many transaction retries within one session.';
$_['text_trans_code']['6001'] = 'The transaction could not be inserted into the batch file for triggering capture.';
$_['text_trans_code']['6002'] = 'There is no batch response file corresponding to the batch request for capture.';
$_['text_trans_code']['6003'] = 'The number of transactions in the batch response file does not match the number of transactions in the corresponding batch request file for capture.';
$_['text_trans_code']['6004'] = 'Identifier Field Missing – an important field or identifier (for example, trace_id or n-file name) is missing when trying to process the batch file and retrieve a transaction from database.';
$_['text_trans_code']['6005'] = 'An unknown error was reported for the transaction during batch processing.';
$_['text_trans_code']['6006'] = 'A duplicate of the batch file was sent to the processor to capture the transaction.';
$_['text_trans_code']['6007'] = 'A duplicate of this transaction was sent to the processor in the batch file to Capture the transaction.';
$_['text_trans_code']['6008'] = 'Technical error with the 3DS processing.';
$_['text_trans_code']['6009'] = 'Technical error in Risk module.';
$_['text_trans_code']['7001'] = 'The refund cannot be processed by RaiAccept because of invalid data.';
$_['text_trans_code']['7002'] = 'The provided response from processor is missing business data critical to continue with the transaction.';
$_['text_trans_code']['7003'] = 'The transaction was not processed due to technical error connected to Tokenizer service. The consumer can try again shortly.';
$_['text_trans_code']['7004'] = 'There was a technical error and the transaction was not processed. The consumer can try again shortly.';
$_['text_trans_code']['7005'] = 'There was data validation error and the transaction cannot be processed. The consumer can try again shortly.';
$_['text_trans_code']['7006'] = 'The transaction cannot be processed within the expected time and is therefore cancelled by the Gateway. The consumer is not charged and can try again shortly.';
$_['text_trans_code']['7007'] = 'The reversal request encounters a technical error.';
$_['text_trans_code']['7008'] = 'Authentication is declined by the 3DS router.';
$_['text_trans_code']['9999'] = 'The transaction was not processed due to an unknown technical error. Please contact support.';

// Success
$_['success_refunded']                     = 'Successfully refunded %s %s';
$_['success_authorization']                = 'Successfully authenticated %s %s';
$_['success_authorization_deny']           = 'Successfully refused authorization %s %s';